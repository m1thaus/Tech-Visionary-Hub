// Write JavaScript here
const searchButton = document.querySelector('button');

searchButton.addEventListener('click', () => {
  const searchTerm = document.querySelector('input').value

  // Fazer a pesquisa usando o termo de pesquisa.
});
